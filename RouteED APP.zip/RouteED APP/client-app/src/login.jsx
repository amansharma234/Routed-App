import React from 'react'
import Button from './assets/button'
import { Link } from 'react-router-dom'
const Login = () => {
  return (
    <>
    <h3>LOG IN</h3>
    
    <input type="email" placeholder='Email' />

    <input type='password' placeholder='Password' />
    
    <Button text={'Log In'}/>
    <p>No Accout??</p> <Link to='/register'>Sign Up</Link>
    </>
  )
}

export default Login