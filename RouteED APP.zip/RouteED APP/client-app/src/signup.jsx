import React from 'react'
import Button from './assets/button'
import {Link} from 'react-router-dom'
const Signup = () => {
  return (
    <>
    <h3>SIGN UP</h3>
    <input type="text" placeholder='Name' />
    
    <input type="email" placeholder='Email' />

    <input type='password' placeholder='Password' />
    <input type="password" placeholder='Confirm Password' />
    
    <Button text={'Sign Up'}/>
    <p>Already Have an Account?</p> <Link to={'/login'}>Login</Link>
    </>
  )
}

export default Signup