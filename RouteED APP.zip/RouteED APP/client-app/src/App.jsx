import React from 'react'
import Signup from './signup.jsx'
import {BrowserRouter, Link, Routes, Route} from 'react-router-dom'
import Login from './login.jsx'
import Home from './home.jsx'
const App = () => {
  return (
    <>
    <Home />    
      <BrowserRouter>
        <Link to="/login">Login</Link> /   
        <Link to={"/register"}> Signup</Link>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Signup />} />
        </Routes>
      </BrowserRouter>
    
    </>
  )
}

export default App
