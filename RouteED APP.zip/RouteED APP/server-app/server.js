import express from "express";
import dotenv from "dotenv";
import cors from "cors";

dotenv.config();

const port = process.env.PORT || 5001

const app = express();

app.get("/", (req, res) =>{
    res.send("Server me aapka swagat hai");
});

app.listen(port, () => {
    console.log(`safalta Purvak Server chal rha hai port number: ${port} pr`);
})